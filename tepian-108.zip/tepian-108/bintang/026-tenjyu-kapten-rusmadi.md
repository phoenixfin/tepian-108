# Kapten Rusmadi

<!-- data:mulai (dibuat otomatis oleh alat/bangun.py, jangan diubah manual) -->
| | |
|---|---|
| Nomor | 26 dari 108 |
| Bintang | Tenjyu 天寿 (bintang langit) |
| Nama | Kapten Rusmadi |
| Usia dan asal | 50, Banjar |
| Segmen | B, Adat (Tanah dan sumpah) |
| Peran | Kapten tongkang Barito |
| Masuk cerita | Babak 2, direkrut oleh Jeki |
| Status | Terbuka untuk diadopsi |
| Pengadopsi | Belum ada |
<!-- data:selesai -->

## Kanon

Ringkasan kanon tokoh ini ada di [`bible/03-bible-tokoh.md`](../bible/03-bible-tokoh.md).
Bagian di bawah ini diisi pengadopsi dan ditinjau kurator sebelum menjadi kanon luas.

## Latar dan suara

_Belum diisi._

## Luka atau kebutuhan

_Belum diisi._

## Adegan kunci

_Belum diisi._

## Relasi

_Belum diisi._

## Catatan riset

_Sumber, catatan bahasa daerah, atau detail lokal yang dipakai._
